const { setWorldConstructor } = require("cucumber");
const { Expect } = require("chai");
const puppeteer =  require("puppeteer");

class CustomWorld {
    async launchBrowser(){
        this.broser = await puppeteer.launch({headless:false});
        this.page = await this.broser.newPage();
    }

    async closeBrowser(){
        this.broser.close();
    }

    async visit(){
        await this.page.goto("http://zero.webappsecurity.com/login.html");

    }


}


setWorldConstructor(CustomWorld);