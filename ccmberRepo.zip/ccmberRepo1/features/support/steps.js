const {Given, When, Then, Before, After} = require("cucumber");

Before(async function(){

    return await this.launchBrowser();
});

After(async function(){

    return await this.closeBrowser();
});

Given ("I opene a login page", async function(){

    return await this.visit();

});

